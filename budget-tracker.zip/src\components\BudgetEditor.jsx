import { useState } from "react";
import { Field, fieldProps } from "./Field";
import { validateAmount } from "../lib/validation";

function BudgetRow({ category, budget, onSave, onRemove }) {
  const [value, setValue] = useState(budget ? budget.amount : "");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const id = `budget-${category.id}`;

  async function save(e) {
    e.preventDefault();
    if (busy) return;
    const problem = validateAmount(value);
    setError(problem || "");
    if (problem) return;
    setBusy(true);
    try {
      await onSave(category.id, value);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    setBusy(true);
    try {
      await onRemove(category.id);
      setValue("");
      setError("");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="budget-row" onSubmit={save} noValidate>
      <span className="cat-name">
        <span className="dot" style={{ background: category.color }} aria-hidden="true" />
        {category.name}
      </span>
      <Field id={id} label="Budget (€)" error={error}>
        <input
          {...fieldProps(id, error)}
          inputMode="decimal"
          placeholder="No budget"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
      </Field>
      <div className="row">
        <button type="submit" disabled={busy}>
          Save
        </button>
        {budget && (
          <button type="button" onClick={remove} disabled={busy}>
            Remove
          </button>
        )}
      </div>
    </form>
  );
}

export default function BudgetEditor({ month, categories, budgets, onSave, onRemove }) {
  if (categories.length === 0) return <p className="muted">Add a category first.</p>;
  return (
    <div>
      {categories.map((c) => (
        <BudgetRow
          key={`${month}-${c.id}`}
          category={c}
          budget={budgets.find((b) => b.month === month && b.category_id === c.id)}
          onSave={onSave}
          onRemove={onRemove}
        />
      ))}
    </div>
  );
}