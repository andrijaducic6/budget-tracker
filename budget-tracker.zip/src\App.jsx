import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import * as api from "./api";
import { useBudgetData } from "./hooks/useBudgetData";
import { applyFilters } from "./lib/filters";
import { formatMonth, newestMonth } from "./lib/months";
import { monthlySummary } from "./lib/summary";
import { formatEuro, toCents } from "./lib/money";
import MonthNav from "./components/MonthNav";
import Summary from "./components/Summary";
import Filters from "./components/Filters";
import TransactionList from "./components/TransactionList";
import TransactionForm from "./components/TransactionForm";
import ConfirmDialog from "./components/ConfirmDialog";
import BudgetEditor from "./components/BudgetEditor";
import CategoryManager from "./components/CategoryManager";
import { Loading, ErrorState, Empty } from "./components/States";

export default function App() {
  const { categories, transactions, budgets, status, reload, mutate } = useBudgetData();
  const [params, setParams] = useSearchParams();
  const [editing, setEditing] = useState(null); 
  const [confirm, setConfirm] = useState(null); 
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState("");

  // Mesec, filteri i sortiranje 
  const urlMonth = params.get("month");
  const month = /^\d{4}-(0[1-9]|1[0-2])$/.test(urlMonth || "") ? urlMonth : newestMonth(transactions);
  const filters = {
    category: params.get("category") || "",
    type: params.get("type") || "",
    q: params.get("q") || "",
    sort: params.get("sort") || "date",
  };

  function update(changes, replace = false) {
    const next = new URLSearchParams(params);
    for (const [key, value] of Object.entries(changes)) {
      if (value) next.set(key, value);
      else next.delete(key);
    }
    setParams(next, { replace });
  }

  // upiši početni mesec
  useEffect(() => {
    if (status === "ready" && !params.get("month")) {
      const next = new URLSearchParams(params);
      next.set("month", newestMonth(transactions));
      setParams(next, { replace: true });
    }
  }, [status, params, transactions, setParams]);

  const monthTransactions = useMemo(
    () => transactions.filter((t) => t.date.startsWith(month)),
    [transactions, month]
  );

  async function saveTransaction(values) {
    if (editing === "new") await mutate(() => api.createTransaction(values));
    else await mutate(() => api.updateTransaction(editing.id, values));
    setEditing(null);
  }

  // brisanje transakcije, brisanje kategorije i reset
  async function handleConfirm() {
    setBusy(true);
    setActionError("");
    try {
      if (confirm.kind === "transaction") await mutate(() => api.deleteTransaction(confirm.item.id));
      else if (confirm.kind === "category") await mutate(() => api.deleteCategory(confirm.item.id));
      else if (confirm.kind === "reset") {
        await mutate(api.resetData);
        setEditing(null);
      }
    } catch (err) {
      setActionError(err.message);
    } finally {
      setConfirm(null);
      setBusy(false);
    }
  }

  let confirmTitle = "";
  let confirmMessage = "";
  let confirmLabel = "Delete";
  if (confirm?.kind === "category") {
    confirmTitle = "Delete category?";
    confirmMessage = `“${confirm.item.name}” and its budgets will be deleted.`;
  } else if (confirm?.kind === "transaction") {
    confirmTitle = "Delete transaction?";
    confirmMessage = `${confirm.item.description || "This transaction"} (${formatEuro(toCents(confirm.item.amount))}) will be deleted.`;
  } else if (confirm?.kind === "reset") {
    confirmTitle = "Reset all data?";
    confirmMessage = "Everything you added or changed will be lost and the starting data will be restored.";
    confirmLabel = "Reset";
  }

  return (
    <div className="app">
      <header className="top">
  <h1>Budget Tracker</h1>
  {status === "ready" && (
    <button type="button" onClick={() => setConfirm({ kind: "reset" })} disabled={busy}>
      Reset data
    </button>
  )}
</header>

      {status === "loading" && <Loading />}
      {status === "error" && <ErrorState onRetry={reload} />}

      {status === "ready" && (
        <main>
          <MonthNav month={month} onChange={(m) => update({ month: m })} />

          {actionError && (
            <p role="alert" className="error">
              {actionError}
            </p>
          )}

          {}
          <Summary summary={monthlySummary({ transactions, budgets, categories, month })} />

          <section aria-labelledby="tx-heading">
            <div className="row between">
              <h2 id="tx-heading">Transactions</h2>
              <button type="button" className="primary" onClick={() => setEditing("new")}>
                Add transaction
              </button>
            </div>

            {editing && (
              <TransactionForm
                key={editing === "new" ? "new" : editing.id}
                categories={categories}
                initial={editing === "new" ? null : editing}
                defaultDate={`${month}-01`}
                onSubmit={saveTransaction}
                onCancel={() => setEditing(null)}
              />
            )}

            <Filters
              categories={categories}
              values={filters}
              onChange={update}
              onClear={() => update({ category: "", type: "", q: "" })}
            />

            {(() => {
              const list = applyFilters(monthTransactions, filters);
              if (list.length === 0) {
                return (
                  <Empty>
                    {monthTransactions.length === 0
                      ? "No transactions in this month."
                      : "No transactions match the filters."}
                  </Empty>
                );
              }
              return (
                <TransactionList
                  transactions={list}
                  categories={categories}
                  onEdit={(t) => setEditing(t)}
                  onDelete={(t) => setConfirm({ kind: "transaction", item: t })}
                />
              );
            })()}
          </section>

          <details className="card" name="panels">
            <summary>Budgets for {formatMonth(month)}</summary>
            <BudgetEditor
              month={month}
              categories={categories}
              budgets={budgets}
              onSave={(categoryId, amount) => mutate(() => api.setBudget(month, categoryId, amount))}
              onRemove={(categoryId) => mutate(() => api.clearBudget(month, categoryId))}
            />
          </details>

          <details className="card" name="panels">
            <summary>Categories</summary>
            <CategoryManager
              categories={categories}
              transactions={transactions}
              onCreate={(name, color) => mutate(() => api.createCategory(name, color))}
              onUpdate={(id, name, color) => mutate(() => api.updateCategory(id, name, color))}
              onDelete={(category) => setConfirm({ kind: "category", item: category })}
            />
          </details>
        </main>
      )}

      <ConfirmDialog
        open={confirm !== null}
        title={confirmTitle}
        message={confirmMessage}
        confirmLabel={confirmLabel}
        busy={busy}
        onConfirm={handleConfirm}
        onCancel={() => setConfirm(null)}
      />
    </div>
  );
}