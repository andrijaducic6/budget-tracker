import { useRef, useState } from "react";
import { Field, fieldProps } from "./Field";
import { validateTransaction } from "../lib/validation";

export default function TransactionForm({ categories, initial, defaultDate, onSubmit, onCancel }) {
  const [values, setValues] = useState({
    type: initial?.type ?? "expense",
    amount: initial?.amount ?? "",
    date: initial?.date ?? defaultDate,
    category_id: initial ? String(initial.category_id) : "",
    description: initial?.description ?? "",
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const busy = useRef(false); // štiti od dvostrukog klika čak i pre ponovnog iscrtavanja

  const set = (field) => (e) => setValues({ ...values, [field]: e.target.value });

  async function handleSubmit(e) {
    e.preventDefault();
    if (busy.current) return;

    const found = validateTransaction(values);
    setErrors(found);
    if (Object.keys(found).length > 0) return;

    busy.current = true;
    setSaving(true);
    setFormError("");
    try {
      await onSubmit(values);
    } catch (err) {
      setFormError(err.message);
    } finally {
      busy.current = false;
      setSaving(false);
    }
  }

  const title = initial ? "Edit transaction" : "Add transaction";

  return (
    <form className="card tx-form" onSubmit={handleSubmit} noValidate aria-label={title}>
      <h3>{title}</h3>

      <Field id="tx-type" label="Type" error={errors.type}>
        <select {...fieldProps("tx-type", errors.type)} value={values.type} onChange={set("type")}>
          <option value="expense">Expense</option>
          <option value="income">Income</option>
        </select>
      </Field>

      <Field id="tx-amount" label="Amount (€)" error={errors.amount}>
        <input
          {...fieldProps("tx-amount", errors.amount)}
          inputMode="decimal"
          autoFocus
          value={values.amount}
          onChange={set("amount")}
        />
      </Field>

      <Field id="tx-date" label="Date" error={errors.date}>
        <input {...fieldProps("tx-date", errors.date)} type="date" value={values.date} onChange={set("date")} />
      </Field>

      <Field id="tx-category" label="Category" error={errors.category_id}>
        <select
          {...fieldProps("tx-category", errors.category_id)}
          value={values.category_id}
          onChange={set("category_id")}
        >
          <option value="">Select a category</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </Field>

      <Field id="tx-description" label="Description (optional)" error={errors.description}>
        <input
          {...fieldProps("tx-description", errors.description)}
          value={values.description}
          onChange={set("description")}
        />
      </Field>

      {formError && (
        <p role="alert" className="error">
          {formError}
        </p>
      )}

      <div className="row">
        <button type="submit" className="primary" disabled={saving}>
          {saving ? "Saving…" : "Save"}
        </button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}