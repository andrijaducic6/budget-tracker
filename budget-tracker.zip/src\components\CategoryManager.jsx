import { useState } from "react";
import { Field, fieldProps } from "./Field";
import { validateCategory } from "../lib/validation";

function CategoryRow({ category, categories, txCount, onSave, onDelete }) {
  const [name, setName] = useState(category.name);
  const [color, setColor] = useState(category.color);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const nameId = `cat-name-${category.id}`;

  async function save(e) {
    e.preventDefault();
    if (busy) return;
    const problem = validateCategory(name, categories, category.id);
    setError(problem || "");
    if (problem) return;
    setBusy(true);
    try {
      await onSave(category.id, name, color);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  function remove() {
    if (txCount > 0) {
      setError(
        `Cannot delete: ${txCount} transaction${txCount === 1 ? "" : "s"} use this category. Move or delete them first.`
      );
      return;
    }
    setError("");
    onDelete(category);
  }

  return (
    <form className="budget-row" onSubmit={save} noValidate>
      <Field id={nameId} label="Name" error={error}>
        <input {...fieldProps(nameId, error)} value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <div className="field">
        <label htmlFor={`cat-color-${category.id}`}>Color</label>
        <input
          id={`cat-color-${category.id}`}
          type="color"
          value={color}
          onChange={(e) => setColor(e.target.value)}
        />
      </div>
      <div className="row">
        <button type="submit" disabled={busy}>
          Save
        </button>
        <button type="button" onClick={remove}>
          Delete
        </button>
      </div>
    </form>
  );
}

export default function CategoryManager({ categories, transactions, onCreate, onUpdate, onDelete }) {
  const [name, setName] = useState("");
  const [color, setColor] = useState("#1976d2");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function add(e) {
    e.preventDefault();
    if (busy) return;
    const problem = validateCategory(name, categories);
    setError(problem || "");
    if (problem) return;
    setBusy(true);
    try {
      await onCreate(name, color);
      setName("");
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <form className="budget-row" onSubmit={add} noValidate>
        <Field id="new-cat-name" label="New category name" error={error}>
          <input
            {...fieldProps("new-cat-name", error)}
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Field>
        <div className="field">
          <label htmlFor="new-cat-color">Color</label>
          <input id="new-cat-color" type="color" value={color} onChange={(e) => setColor(e.target.value)} />
        </div>
        <button type="submit" className="primary" disabled={busy}>
          Add category
        </button>
      </form>

      {categories.map((c) => (
        <CategoryRow
          key={`${c.id}-${c.name}-${c.color}`}
          category={c}
          categories={categories}
          txCount={transactions.filter((t) => t.category_id === c.id).length}
          onSave={onUpdate}
          onDelete={onDelete}
        />
      ))}
    </div>
  );
}