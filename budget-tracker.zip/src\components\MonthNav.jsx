import { formatMonth, shiftMonth } from "../lib/months";

export default function MonthNav({ month, onChange }) {
  return (
    <nav className="month-nav" aria-label="Month">
      <button type="button" onClick={() => onChange(shiftMonth(month, -1))} aria-label="Previous month">
        ‹
      </button>
      <h2 aria-live="polite">{formatMonth(month)}</h2>
      <button type="button" onClick={() => onChange(shiftMonth(month, 1))} aria-label="Next month">
        ›
      </button>
    </nav>
  );
}