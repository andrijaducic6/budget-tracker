export function Loading() {
  return (
    <p className="state" role="status">
      Loading data…
    </p>
  );
}

export function ErrorState({ onRetry }) {
  return (
    <div className="state" role="alert">
      <p>Something went wrong while loading the data.</p>
      <button type="button" className="primary" onClick={onRetry}>
        Try again
      </button>
    </div>
  );
}

export function Empty({ children }) {
  return <p className="state muted">{children}</p>;
}