import { useCallback, useEffect, useState } from "react";
import * as api from "../api";

export function useBudgetData() {
  const [data, setData] = useState({ categories: [], transactions: [], budgets: [] });
  const [status, setStatus] = useState("loading"); // loading | ready | error
  const [attempt, setAttempt] = useState(0); // raste kad korisnik klikne "Try again"

  useEffect(() => {
    let cancelled = false;

    async function load() {
      try {
        const [categories, transactions, budgets] = await Promise.all([
          api.getCategories(),
          api.getTransactions(),
          api.getBudgets(),
        ]);
        if (cancelled) return;
        setData({ categories, transactions, budgets });
        setStatus("ready");
      } catch {
        if (!cancelled) setStatus("error");
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [attempt]);

  // "loading"
  const reload = useCallback(() => {
    setStatus("loading");
    setAttempt((n) => n + 1);
  }, []);

  
  const mutate = useCallback(async (fn) => {
    const snapshot = await fn();
    setData(snapshot);
  }, []);

  return { ...data, status, reload, mutate };
}