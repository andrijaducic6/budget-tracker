import { formatEuro } from "../lib/money";

export default function Summary({ summary }) {
  const { income, expense, balance, rows } = summary;

  return (
    <section className="card" aria-labelledby="summary-heading">
      <h2 id="summary-heading">Monthly summary</h2>

      <dl className="totals">
        <div>
          <dt>Income</dt>
          <dd className="income">{formatEuro(income)}</dd>
        </div>
        <div>
          <dt>Expenses</dt>
          <dd className="expense">{formatEuro(expense)}</dd>
        </div>
        <div>
          <dt>Balance</dt>
          <dd className={balance < 0 ? "expense" : ""}>
            {formatEuro(balance)}
            {balance < 0 && " (negative)"}
          </dd>
        </div>
      </dl>

      {rows.length === 0 ? (
        <p className="muted">No expenses or budgets in this month.</p>
      ) : (
        <ul className="cat-rows">
          {rows.map((r) => (
            <li key={r.categoryId}>
              <div className="row between">
                <span className="cat-name">
                  <span className="dot" style={{ background: r.color }} aria-hidden="true" />
                  {r.name}
                </span>
                <span>
                  {formatEuro(r.spent)}
                  {r.budget !== null && ` / ${formatEuro(r.budget)}`}
                </span>
              </div>
              {r.budget !== null && (
                <>
                  <div
                    className={`bar ${r.over ? "over" : ""}`}
                    role="progressbar"
                    aria-label={`${r.name} budget used`}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    aria-valuenow={r.percent}
                  >
                    <span style={{ width: `${r.percent}%` }} />
                  </div>
                  <p className={r.over ? "over-text" : "muted"}>
                    {r.over
                      ? `⚠ Over budget by ${formatEuro(-r.remaining)}`
                      : `${formatEuro(r.remaining)} left`}
                  </p>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}