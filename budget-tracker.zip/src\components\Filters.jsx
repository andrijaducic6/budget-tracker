export default function Filters({ categories, values, onChange, onClear }) {
  return (
    <form className="filters" onSubmit={(e) => e.preventDefault()} aria-label="Filters">
      <div className="field">
        <label htmlFor="f-q">Search description</label>
        <input
          id="f-q"
          type="search"
          value={values.q}
          onChange={(e) => onChange({ q: e.target.value }, true)}
        />
      </div>
      <div className="field">
        <label htmlFor="f-category">Category</label>
        <select
          id="f-category"
          value={values.category}
          onChange={(e) => onChange({ category: e.target.value })}
        >
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>
      <div className="field">
        <label htmlFor="f-type">Type</label>
        <select id="f-type" value={values.type} onChange={(e) => onChange({ type: e.target.value })}>
          <option value="">Income and expenses</option>
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
      </div>
      <div className="field">
        <label htmlFor="f-sort">Sort by</label>
        <select
          id="f-sort"
          value={values.sort}
          onChange={(e) => onChange({ sort: e.target.value === "date" ? "" : e.target.value })}
        >
          <option value="date">Newest first</option>
          <option value="amount">Highest amount</option>
        </select>
      </div>
      <button type="button" onClick={onClear}>
        Clear filters
      </button>
    </form>
  );
}