import seed from "./data/budget-data.json";
import { fromCents, toCents } from "./lib/money";
import { upsertBudget, removeBudget, removeCategoryBudgets } from "./lib/budgets";

const KEY = "budget-tracker-v1";
const wait = (ms = 500) => new Promise((resolve) => setTimeout(resolve, ms));

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    
  }
  return structuredClone(seed);
}

function save(data) {
  localStorage.setItem(KEY, JSON.stringify(data));
  return data;
}

const nextId = (list) => list.reduce((max, item) => Math.max(max, item.id), 0) + 1;

async function read(pick) {
  await wait();
  if (new URLSearchParams(window.location.search).get("fail") === "1") {
    throw new Error("Could not load data");
  }
  return pick(load());
}


async function change(fn) {
  await wait();
  const data = load();
  fn(data);
  return save(data);
}

const clean = (v) => ({
  type: v.type,
  amount: fromCents(toCents(v.amount)),
  date: v.date,
  category_id: Number(v.category_id),
  description: v.description && v.description.trim() ? v.description.trim() : null,
});

export const getCategories = () => read((d) => d.categories);
export const getTransactions = () => read((d) => d.transactions);
export const getBudgets = () => read((d) => d.budgets);

export const createTransaction = (values) =>
  change((d) => {
    d.transactions.push({ id: nextId(d.transactions), ...clean(values) });
  });

export const updateTransaction = (id, values) =>
  change((d) => {
    const index = d.transactions.findIndex((t) => t.id === id);
    if (index === -1) throw new Error("Transaction not found");
    d.transactions[index] = { id, ...clean(values) };
  });

export const deleteTransaction = (id) =>
  change((d) => {
    d.transactions = d.transactions.filter((t) => t.id !== id);
  });

export const createCategory = (name, color) =>
  change((d) => {
    d.categories.push({ id: nextId(d.categories), name: name.trim(), color });
  });

export const updateCategory = (id, name, color) =>
  change((d) => {
    const category = d.categories.find((c) => c.id === id);
    if (!category) throw new Error("Category not found");
    category.name = name.trim();
    category.color = color;
  });

export const deleteCategory = (id) =>
  change((d) => {
    if (d.transactions.some((t) => t.category_id === id)) {
      throw new Error("This category has transactions and cannot be deleted");
    }
    d.categories = d.categories.filter((c) => c.id !== id);
    d.budgets = removeCategoryBudgets(d.budgets, id);
  });

export const setBudget = (month, categoryId, amount) =>
  change((d) => {
    d.budgets = upsertBudget(d.budgets, month, categoryId, amount);
  });

export const clearBudget = (month, categoryId) =>
  change((d) => {
    d.budgets = removeBudget(d.budgets, month, categoryId);
  });

export async function resetData() {
  await wait();
  return save(structuredClone(seed));
}