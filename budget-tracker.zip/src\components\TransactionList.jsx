import { formatEuro, toCents } from "../lib/money";
import { formatDate } from "../lib/months";

export default function TransactionList({ transactions, categories, onEdit, onDelete }) {
  const byId = new Map(categories.map((c) => [c.id, c]));

  return (
    <ul className="tx-list">
      {transactions.map((t) => {
        const category = byId.get(t.category_id);
        const income = t.type === "income";
        const label = t.description || "transaction";
        return (
          <li key={t.id} className="tx">
            <div className="tx-main">
              <span className="muted">{formatDate(t.date)}</span>
              <strong className="tx-desc">{t.description || "No description"}</strong>
              <span className="cat-name">
                <span className="dot" style={{ background: category?.color }} aria-hidden="true" />
                {category?.name ?? "Unknown"}
              </span>
            </div>
            <div className="tx-side">
              <span className={`badge ${t.type}`}>{income ? "▲ Income" : "▼ Expense"}</span>
              <span className={`amount ${t.type}`}>
                {income ? "+" : "−"}
                {formatEuro(toCents(t.amount))}
              </span>
            </div>
            {(onEdit || onDelete) && (
              <div className="row">
                {onEdit && (
                  <button type="button" onClick={() => onEdit(t)} aria-label={`Edit ${label} from ${t.date}`}>
                    Edit
                  </button>
                )}
                {onDelete && (
                  <button type="button" onClick={() => onDelete(t)} aria-label={`Delete ${label} from ${t.date}`}>
                    Delete
                  </button>
                )}
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}