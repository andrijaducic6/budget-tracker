# Budget Tracker

Personal budget tracker built with React (Vite). There is no backend: the data starts
from `src/data/budget-data.json` and every change is saved in the browser (localStorage).

## Run the app

    npm install
    npm run dev

Open the address shown in the terminal (usually http://localhost:5173).

- Add `?fail=1` to the address to see the loading error state and the "Try again" button.
- "Reset data" goes back to the data from `budget-data.json`.

## Run the tests

    npm test

Unit tests cover the monthly summary, budgets, form validation, filters/sorting,
money helpers and month helpers (32 tests).

## Project structure

- `src/api.js` – the only place that reads and saves data. Async functions with a 500 ms
  delay, `?fail=1` support and localStorage persistence.
- `src/lib/` – pure logic without React (tested): money in cents, monthly summary,
  budgets, validation, filters, months.
- `src/hooks/useBudgetData.js` – loading, error state and updating the data.
- `src/components/` – the parts of the screen.
- `src/App.jsx` – puts the screen together and keeps month, filters and sort in the page address.

## Decisions

- Money is converted to whole cents before any calculation, so 0.10 + 0.20 is always 0.30.
- Month, filters and sort are kept in the page address (`?month=2026-10&type=expense&q=shop&sort=amount`),
  so a reload or a shared link opens the same view.
- The summary always covers the whole month. Filters change only the list.
- Income and expenses differ by label, arrow and sign (+ / −), not only by color.
  Over budget is shown with a warning text and a striped bar, not only red.
- Validation runs in the form (errors next to the fields), and the important rules are
  checked again in `api.js` (for example, a category with transactions cannot be deleted).
- Saving twice by double click is blocked with a ref and a disabled button.

## Known limitations

- Components are not covered by tests, only the logic in `src/lib/`.
- A budget can also be set for an income category; it is shown in the summary like any other.
- Data lives in one browser only (localStorage).